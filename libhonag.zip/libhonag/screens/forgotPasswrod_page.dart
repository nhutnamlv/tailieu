import 'package:flutter/material.dart';
import 'package:flutter_app/db/db_helper.dart';

class ForgotPasswordPage extends StatefulWidget {
  const ForgotPasswordPage({super.key});

  @override
  State<ForgotPasswordPage> createState() => _ForgotPasswordPageState();
}

class _ForgotPasswordPageState extends State<ForgotPasswordPage> {
  final emailController = TextEditingController();

  void _handleForgotPassword() async {
    final email = emailController.text.trim();
    final user = await DatabaseHelper().getUserByEmail(email);

    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Không tìm thấy người dùng với email này'),
        ),
      );
      return;
    }

    final password = user['password'];
    await DatabaseHelper().sendEmail(
      toEmail: email,
      subject: 'Khôi phục mật khẩu',
      body: 'Mật khẩu của bạn là: $password',
    );

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Mật khẩu đã được gửi đến email')),
    );

    Navigator.pop(context); // Quay lại trang trước
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Khôi phục mật khẩu'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 40.0, bottom: 32.0),
                child: Image.asset('assets/logo.jpg', height: 120, width: 120),
              ),
              const Text(
                'Nhập email để khôi phục mật khẩu',
                style: TextStyle(fontSize: 16.0),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: emailController,
                decoration: const InputDecoration(
                  labelText: 'Email',
                  prefixIcon: Icon(Icons.email_outlined),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(12.0)),
                  ),
                ),
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _handleForgotPassword,
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 50),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                ),
                child: const Text(
                  'Gửi mật khẩu',
                  style: TextStyle(fontSize: 16.0),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
